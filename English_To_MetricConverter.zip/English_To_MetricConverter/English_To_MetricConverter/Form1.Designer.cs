﻿namespace English_To_MetricConverter
{
    partial class frmEnglishToMetric
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpEnglishToMetric = new System.Windows.Forms.GroupBox();
            this.lblYards = new System.Windows.Forms.Label();
            this.lblIches = new System.Windows.Forms.Label();
            this.lblMiles = new System.Windows.Forms.Label();
            this.lblFeet = new System.Windows.Forms.Label();
            this.btnEnglishToMetricClear = new System.Windows.Forms.Button();
            this.txtYards = new System.Windows.Forms.TextBox();
            this.txtInches = new System.Windows.Forms.TextBox();
            this.txtMiles = new System.Windows.Forms.TextBox();
            this.txtFeet = new System.Windows.Forms.TextBox();
            this.grpMetricEnglishToMetric = new System.Windows.Forms.GroupBox();
            this.lblKilometer = new System.Windows.Forms.Label();
            this.lblCentimeter = new System.Windows.Forms.Label();
            this.lblMeter = new System.Windows.Forms.Label();
            this.btnMetricEnglishToMetricClear = new System.Windows.Forms.Button();
            this.txtKilo = new System.Windows.Forms.TextBox();
            this.txtCenti = new System.Windows.Forms.TextBox();
            this.txtMeters = new System.Windows.Forms.TextBox();
            this.lblMetrictoEnglish = new System.Windows.Forms.Label();
            this.grpMetricToEnglish = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnMetricToEnglishClear = new System.Windows.Forms.Button();
            this.txtMetricKilo = new System.Windows.Forms.TextBox();
            this.txtMetricCenti = new System.Windows.Forms.TextBox();
            this.txtMetricMeter = new System.Windows.Forms.TextBox();
            this.grpEnglishMetricToEnglish = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnEnglishMetricToEnglishClear = new System.Windows.Forms.Button();
            this.txtMetricYard = new System.Windows.Forms.TextBox();
            this.txtMetricInches = new System.Windows.Forms.TextBox();
            this.txtMetricMiles = new System.Windows.Forms.TextBox();
            this.txtMetricFeet = new System.Windows.Forms.TextBox();
            this.lblEnglishtoMetric = new System.Windows.Forms.Label();
            this.optEnglishToMetric = new System.Windows.Forms.RadioButton();
            this.optMetricToEnglish = new System.Windows.Forms.RadioButton();
            this.btnConvert = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.grpEnglishToMetric.SuspendLayout();
            this.grpMetricEnglishToMetric.SuspendLayout();
            this.grpMetricToEnglish.SuspendLayout();
            this.grpEnglishMetricToEnglish.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(306, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(166, 31);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Conversions";
            // 
            // grpEnglishToMetric
            // 
            this.grpEnglishToMetric.Controls.Add(this.lblYards);
            this.grpEnglishToMetric.Controls.Add(this.lblIches);
            this.grpEnglishToMetric.Controls.Add(this.lblMiles);
            this.grpEnglishToMetric.Controls.Add(this.lblFeet);
            this.grpEnglishToMetric.Controls.Add(this.btnEnglishToMetricClear);
            this.grpEnglishToMetric.Controls.Add(this.txtYards);
            this.grpEnglishToMetric.Controls.Add(this.txtInches);
            this.grpEnglishToMetric.Controls.Add(this.txtMiles);
            this.grpEnglishToMetric.Controls.Add(this.txtFeet);
            this.grpEnglishToMetric.Enabled = false;
            this.grpEnglishToMetric.Location = new System.Drawing.Point(153, 101);
            this.grpEnglishToMetric.Name = "grpEnglishToMetric";
            this.grpEnglishToMetric.Size = new System.Drawing.Size(217, 172);
            this.grpEnglishToMetric.TabIndex = 1;
            this.grpEnglishToMetric.TabStop = false;
            this.grpEnglishToMetric.Text = "English";
            // 
            // lblYards
            // 
            this.lblYards.AutoSize = true;
            this.lblYards.Location = new System.Drawing.Point(11, 97);
            this.lblYards.Name = "lblYards";
            this.lblYards.Size = new System.Drawing.Size(20, 13);
            this.lblYards.TabIndex = 8;
            this.lblYards.Text = "Yd";
            // 
            // lblIches
            // 
            this.lblIches.AutoSize = true;
            this.lblIches.Location = new System.Drawing.Point(11, 71);
            this.lblIches.Name = "lblIches";
            this.lblIches.Size = new System.Drawing.Size(28, 13);
            this.lblIches.TabIndex = 7;
            this.lblIches.Text = "Inch";
            // 
            // lblMiles
            // 
            this.lblMiles.AutoSize = true;
            this.lblMiles.Location = new System.Drawing.Point(11, 47);
            this.lblMiles.Name = "lblMiles";
            this.lblMiles.Size = new System.Drawing.Size(31, 13);
            this.lblMiles.TabIndex = 6;
            this.lblMiles.Text = "Miles";
            // 
            // lblFeet
            // 
            this.lblFeet.AutoSize = true;
            this.lblFeet.Location = new System.Drawing.Point(11, 25);
            this.lblFeet.Name = "lblFeet";
            this.lblFeet.Size = new System.Drawing.Size(16, 13);
            this.lblFeet.TabIndex = 5;
            this.lblFeet.Text = "Ft";
            // 
            // btnEnglishToMetricClear
            // 
            this.btnEnglishToMetricClear.Location = new System.Drawing.Point(119, 135);
            this.btnEnglishToMetricClear.Name = "btnEnglishToMetricClear";
            this.btnEnglishToMetricClear.Size = new System.Drawing.Size(75, 23);
            this.btnEnglishToMetricClear.TabIndex = 4;
            this.btnEnglishToMetricClear.Text = "Clear";
            this.btnEnglishToMetricClear.UseVisualStyleBackColor = true;
            this.btnEnglishToMetricClear.Click += new System.EventHandler(this.btnEnglishToMetricClear_Click);
            // 
            // txtYards
            // 
            this.txtYards.Location = new System.Drawing.Point(55, 94);
            this.txtYards.Name = "txtYards";
            this.txtYards.Size = new System.Drawing.Size(100, 20);
            this.txtYards.TabIndex = 3;
            // 
            // txtInches
            // 
            this.txtInches.Location = new System.Drawing.Point(55, 68);
            this.txtInches.Name = "txtInches";
            this.txtInches.Size = new System.Drawing.Size(100, 20);
            this.txtInches.TabIndex = 2;
            // 
            // txtMiles
            // 
            this.txtMiles.Location = new System.Drawing.Point(55, 44);
            this.txtMiles.Name = "txtMiles";
            this.txtMiles.Size = new System.Drawing.Size(100, 20);
            this.txtMiles.TabIndex = 1;
            this.txtMiles.TextChanged += new System.EventHandler(this.txtMiles_TextChanged);
            // 
            // txtFeet
            // 
            this.txtFeet.Location = new System.Drawing.Point(55, 19);
            this.txtFeet.Name = "txtFeet";
            this.txtFeet.Size = new System.Drawing.Size(100, 20);
            this.txtFeet.TabIndex = 0;
            // 
            // grpMetricEnglishToMetric
            // 
            this.grpMetricEnglishToMetric.Controls.Add(this.lblKilometer);
            this.grpMetricEnglishToMetric.Controls.Add(this.lblCentimeter);
            this.grpMetricEnglishToMetric.Controls.Add(this.lblMeter);
            this.grpMetricEnglishToMetric.Controls.Add(this.btnMetricEnglishToMetricClear);
            this.grpMetricEnglishToMetric.Controls.Add(this.txtKilo);
            this.grpMetricEnglishToMetric.Controls.Add(this.txtCenti);
            this.grpMetricEnglishToMetric.Controls.Add(this.txtMeters);
            this.grpMetricEnglishToMetric.Enabled = false;
            this.grpMetricEnglishToMetric.Location = new System.Drawing.Point(429, 101);
            this.grpMetricEnglishToMetric.Name = "grpMetricEnglishToMetric";
            this.grpMetricEnglishToMetric.Size = new System.Drawing.Size(200, 172);
            this.grpMetricEnglishToMetric.TabIndex = 2;
            this.grpMetricEnglishToMetric.TabStop = false;
            this.grpMetricEnglishToMetric.Text = "Metric";
            // 
            // lblKilometer
            // 
            this.lblKilometer.AutoSize = true;
            this.lblKilometer.Location = new System.Drawing.Point(11, 90);
            this.lblKilometer.Name = "lblKilometer";
            this.lblKilometer.Size = new System.Drawing.Size(24, 13);
            this.lblKilometer.TabIndex = 9;
            this.lblKilometer.Text = "Kilo";
            // 
            // lblCentimeter
            // 
            this.lblCentimeter.AutoSize = true;
            this.lblCentimeter.Location = new System.Drawing.Point(12, 68);
            this.lblCentimeter.Name = "lblCentimeter";
            this.lblCentimeter.Size = new System.Drawing.Size(31, 13);
            this.lblCentimeter.TabIndex = 8;
            this.lblCentimeter.Text = "Centi";
            // 
            // lblMeter
            // 
            this.lblMeter.AutoSize = true;
            this.lblMeter.Location = new System.Drawing.Point(11, 44);
            this.lblMeter.Name = "lblMeter";
            this.lblMeter.Size = new System.Drawing.Size(34, 13);
            this.lblMeter.TabIndex = 7;
            this.lblMeter.Text = "Meter";
            // 
            // btnMetricEnglishToMetricClear
            // 
            this.btnMetricEnglishToMetricClear.Location = new System.Drawing.Point(119, 136);
            this.btnMetricEnglishToMetricClear.Name = "btnMetricEnglishToMetricClear";
            this.btnMetricEnglishToMetricClear.Size = new System.Drawing.Size(75, 23);
            this.btnMetricEnglishToMetricClear.TabIndex = 4;
            this.btnMetricEnglishToMetricClear.Text = "Clear";
            this.btnMetricEnglishToMetricClear.UseVisualStyleBackColor = true;
            this.btnMetricEnglishToMetricClear.Click += new System.EventHandler(this.btnMetricEnglishToMetricClear_Click);
            // 
            // txtKilo
            // 
            this.txtKilo.Location = new System.Drawing.Point(66, 90);
            this.txtKilo.Name = "txtKilo";
            this.txtKilo.Size = new System.Drawing.Size(100, 20);
            this.txtKilo.TabIndex = 2;
            // 
            // txtCenti
            // 
            this.txtCenti.Location = new System.Drawing.Point(66, 64);
            this.txtCenti.Name = "txtCenti";
            this.txtCenti.Size = new System.Drawing.Size(100, 20);
            this.txtCenti.TabIndex = 1;
            // 
            // txtMeters
            // 
            this.txtMeters.Location = new System.Drawing.Point(66, 37);
            this.txtMeters.Name = "txtMeters";
            this.txtMeters.Size = new System.Drawing.Size(100, 20);
            this.txtMeters.TabIndex = 0;
            // 
            // lblMetrictoEnglish
            // 
            this.lblMetrictoEnglish.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMetrictoEnglish.Location = new System.Drawing.Point(296, 286);
            this.lblMetrictoEnglish.Name = "lblMetrictoEnglish";
            this.lblMetrictoEnglish.Size = new System.Drawing.Size(194, 32);
            this.lblMetrictoEnglish.TabIndex = 3;
            this.lblMetrictoEnglish.Text = "Metric to English";
            // 
            // grpMetricToEnglish
            // 
            this.grpMetricToEnglish.Controls.Add(this.label1);
            this.grpMetricToEnglish.Controls.Add(this.label2);
            this.grpMetricToEnglish.Controls.Add(this.label3);
            this.grpMetricToEnglish.Controls.Add(this.btnMetricToEnglishClear);
            this.grpMetricToEnglish.Controls.Add(this.txtMetricKilo);
            this.grpMetricToEnglish.Controls.Add(this.txtMetricCenti);
            this.grpMetricToEnglish.Controls.Add(this.txtMetricMeter);
            this.grpMetricToEnglish.Enabled = false;
            this.grpMetricToEnglish.Location = new System.Drawing.Point(153, 321);
            this.grpMetricToEnglish.Name = "grpMetricToEnglish";
            this.grpMetricToEnglish.Size = new System.Drawing.Size(217, 174);
            this.grpMetricToEnglish.TabIndex = 4;
            this.grpMetricToEnglish.TabStop = false;
            this.grpMetricToEnglish.Text = "Metric";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 13);
            this.label1.TabIndex = 12;
            this.label1.Text = "Kilo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Centi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Meter";
            // 
            // btnMetricToEnglishClear
            // 
            this.btnMetricToEnglishClear.Location = new System.Drawing.Point(119, 145);
            this.btnMetricToEnglishClear.Name = "btnMetricToEnglishClear";
            this.btnMetricToEnglishClear.Size = new System.Drawing.Size(75, 23);
            this.btnMetricToEnglishClear.TabIndex = 3;
            this.btnMetricToEnglishClear.Text = "Clear";
            this.btnMetricToEnglishClear.UseVisualStyleBackColor = true;
            this.btnMetricToEnglishClear.Click += new System.EventHandler(this.btnMetricToEnglishClear_Click);
            // 
            // txtMetricKilo
            // 
            this.txtMetricKilo.Location = new System.Drawing.Point(55, 84);
            this.txtMetricKilo.Name = "txtMetricKilo";
            this.txtMetricKilo.Size = new System.Drawing.Size(100, 20);
            this.txtMetricKilo.TabIndex = 2;
            this.txtMetricKilo.TextChanged += new System.EventHandler(this.txtMetricKilo_TextChanged);
            // 
            // txtMetricCenti
            // 
            this.txtMetricCenti.Location = new System.Drawing.Point(55, 58);
            this.txtMetricCenti.Name = "txtMetricCenti";
            this.txtMetricCenti.Size = new System.Drawing.Size(100, 20);
            this.txtMetricCenti.TabIndex = 1;
            this.txtMetricCenti.TextChanged += new System.EventHandler(this.txtMetricCenti_TextChanged);
            // 
            // txtMetricMeter
            // 
            this.txtMetricMeter.Location = new System.Drawing.Point(55, 32);
            this.txtMetricMeter.Name = "txtMetricMeter";
            this.txtMetricMeter.Size = new System.Drawing.Size(100, 20);
            this.txtMetricMeter.TabIndex = 0;
            this.txtMetricMeter.TextChanged += new System.EventHandler(this.txtMeter_TextChanged);
            // 
            // grpEnglishMetricToEnglish
            // 
            this.grpEnglishMetricToEnglish.Controls.Add(this.label4);
            this.grpEnglishMetricToEnglish.Controls.Add(this.label5);
            this.grpEnglishMetricToEnglish.Controls.Add(this.label6);
            this.grpEnglishMetricToEnglish.Controls.Add(this.label7);
            this.grpEnglishMetricToEnglish.Controls.Add(this.btnEnglishMetricToEnglishClear);
            this.grpEnglishMetricToEnglish.Controls.Add(this.txtMetricYard);
            this.grpEnglishMetricToEnglish.Controls.Add(this.txtMetricInches);
            this.grpEnglishMetricToEnglish.Controls.Add(this.txtMetricMiles);
            this.grpEnglishMetricToEnglish.Controls.Add(this.txtMetricFeet);
            this.grpEnglishMetricToEnglish.Enabled = false;
            this.grpEnglishMetricToEnglish.Location = new System.Drawing.Point(429, 321);
            this.grpEnglishMetricToEnglish.Name = "grpEnglishMetricToEnglish";
            this.grpEnglishMetricToEnglish.Size = new System.Drawing.Size(200, 174);
            this.grpEnglishMetricToEnglish.TabIndex = 5;
            this.grpEnglishMetricToEnglish.TabStop = false;
            this.grpEnglishMetricToEnglish.Text = "Enlgish";
            this.grpEnglishMetricToEnglish.Enter += new System.EventHandler(this.grpEnglishMetricToEnglish_Enter);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(20, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Yd";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Inch";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Miles";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Ft";
            // 
            // btnEnglishMetricToEnglishClear
            // 
            this.btnEnglishMetricToEnglishClear.Location = new System.Drawing.Point(119, 145);
            this.btnEnglishMetricToEnglishClear.Name = "btnEnglishMetricToEnglishClear";
            this.btnEnglishMetricToEnglishClear.Size = new System.Drawing.Size(75, 23);
            this.btnEnglishMetricToEnglishClear.TabIndex = 4;
            this.btnEnglishMetricToEnglishClear.Text = "Clear";
            this.btnEnglishMetricToEnglishClear.UseVisualStyleBackColor = true;
            this.btnEnglishMetricToEnglishClear.Click += new System.EventHandler(this.btnEnglishMetricToEnglishClear_Click);
            // 
            // txtMetricYard
            // 
            this.txtMetricYard.Location = new System.Drawing.Point(49, 109);
            this.txtMetricYard.Name = "txtMetricYard";
            this.txtMetricYard.Size = new System.Drawing.Size(100, 20);
            this.txtMetricYard.TabIndex = 3;
            // 
            // txtMetricInches
            // 
            this.txtMetricInches.Location = new System.Drawing.Point(49, 83);
            this.txtMetricInches.Name = "txtMetricInches";
            this.txtMetricInches.Size = new System.Drawing.Size(100, 20);
            this.txtMetricInches.TabIndex = 2;
            this.txtMetricInches.TextChanged += new System.EventHandler(this.txtMetricInches_TextChanged);
            // 
            // txtMetricMiles
            // 
            this.txtMetricMiles.Location = new System.Drawing.Point(49, 57);
            this.txtMetricMiles.Name = "txtMetricMiles";
            this.txtMetricMiles.Size = new System.Drawing.Size(100, 20);
            this.txtMetricMiles.TabIndex = 1;
            // 
            // txtMetricFeet
            // 
            this.txtMetricFeet.Location = new System.Drawing.Point(49, 31);
            this.txtMetricFeet.Name = "txtMetricFeet";
            this.txtMetricFeet.Size = new System.Drawing.Size(100, 20);
            this.txtMetricFeet.TabIndex = 0;
            // 
            // lblEnglishtoMetric
            // 
            this.lblEnglishtoMetric.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnglishtoMetric.Location = new System.Drawing.Point(290, 54);
            this.lblEnglishtoMetric.Name = "lblEnglishtoMetric";
            this.lblEnglishtoMetric.Size = new System.Drawing.Size(200, 35);
            this.lblEnglishtoMetric.TabIndex = 6;
            this.lblEnglishtoMetric.Text = "English to Metric";
            // 
            // optEnglishToMetric
            // 
            this.optEnglishToMetric.AutoSize = true;
            this.optEnglishToMetric.Location = new System.Drawing.Point(33, 168);
            this.optEnglishToMetric.Name = "optEnglishToMetric";
            this.optEnglishToMetric.Size = new System.Drawing.Size(107, 17);
            this.optEnglishToMetric.TabIndex = 7;
            this.optEnglishToMetric.Text = "English To Metric";
            this.optEnglishToMetric.UseVisualStyleBackColor = true;
            this.optEnglishToMetric.CheckedChanged += new System.EventHandler(this.optEnglishToMetric_CheckedChanged);
            // 
            // optMetricToEnglish
            // 
            this.optMetricToEnglish.AutoSize = true;
            this.optMetricToEnglish.Location = new System.Drawing.Point(33, 223);
            this.optMetricToEnglish.Name = "optMetricToEnglish";
            this.optMetricToEnglish.Size = new System.Drawing.Size(107, 17);
            this.optMetricToEnglish.TabIndex = 8;
            this.optMetricToEnglish.Text = "Metric To English";
            this.optMetricToEnglish.UseVisualStyleBackColor = true;
            this.optMetricToEnglish.CheckedChanged += new System.EventHandler(this.optMetricToEnglish_CheckedChanged);
            // 
            // btnConvert
            // 
            this.btnConvert.Location = new System.Drawing.Point(33, 286);
            this.btnConvert.Name = "btnConvert";
            this.btnConvert.Size = new System.Drawing.Size(75, 23);
            this.btnConvert.TabIndex = 9;
            this.btnConvert.Text = "Convert";
            this.btnConvert.UseVisualStyleBackColor = true;
            this.btnConvert.Click += new System.EventHandler(this.btnConvert_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(676, 285);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 10;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // frmEnglishToMetric
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 565);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnConvert);
            this.Controls.Add(this.optMetricToEnglish);
            this.Controls.Add(this.optEnglishToMetric);
            this.Controls.Add(this.lblEnglishtoMetric);
            this.Controls.Add(this.grpEnglishMetricToEnglish);
            this.Controls.Add(this.grpMetricToEnglish);
            this.Controls.Add(this.lblMetrictoEnglish);
            this.Controls.Add(this.grpMetricEnglishToMetric);
            this.Controls.Add(this.grpEnglishToMetric);
            this.Controls.Add(this.lblTitle);
            this.Name = "frmEnglishToMetric";
            this.Text = "English To Metric";
            this.Load += new System.EventHandler(this.frmEnglishToMetric_Load);
            this.grpEnglishToMetric.ResumeLayout(false);
            this.grpEnglishToMetric.PerformLayout();
            this.grpMetricEnglishToMetric.ResumeLayout(false);
            this.grpMetricEnglishToMetric.PerformLayout();
            this.grpMetricToEnglish.ResumeLayout(false);
            this.grpMetricToEnglish.PerformLayout();
            this.grpEnglishMetricToEnglish.ResumeLayout(false);
            this.grpEnglishMetricToEnglish.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpEnglishToMetric;
        private System.Windows.Forms.Button btnEnglishToMetricClear;
        private System.Windows.Forms.TextBox txtYards;
        private System.Windows.Forms.TextBox txtInches;
        private System.Windows.Forms.TextBox txtMiles;
        private System.Windows.Forms.TextBox txtFeet;
        private System.Windows.Forms.GroupBox grpMetricEnglishToMetric;
        private System.Windows.Forms.Button btnMetricEnglishToMetricClear;
        private System.Windows.Forms.TextBox txtKilo;
        private System.Windows.Forms.TextBox txtCenti;
        private System.Windows.Forms.TextBox txtMeters;
        private System.Windows.Forms.Label lblMetrictoEnglish;
        private System.Windows.Forms.GroupBox grpMetricToEnglish;
        private System.Windows.Forms.Button btnMetricToEnglishClear;
        private System.Windows.Forms.TextBox txtMetricKilo;
        private System.Windows.Forms.TextBox txtMetricCenti;
        private System.Windows.Forms.TextBox txtMetricMeter;
        private System.Windows.Forms.GroupBox grpEnglishMetricToEnglish;
        private System.Windows.Forms.Button btnEnglishMetricToEnglishClear;
        private System.Windows.Forms.TextBox txtMetricYard;
        private System.Windows.Forms.TextBox txtMetricInches;
        private System.Windows.Forms.TextBox txtMetricMiles;
        private System.Windows.Forms.TextBox txtMetricFeet;
        private System.Windows.Forms.Label lblEnglishtoMetric;
        private System.Windows.Forms.Label lblYards;
        private System.Windows.Forms.Label lblIches;
        private System.Windows.Forms.Label lblMiles;
        private System.Windows.Forms.Label lblFeet;
        private System.Windows.Forms.Label lblKilometer;
        private System.Windows.Forms.Label lblCentimeter;
        private System.Windows.Forms.Label lblMeter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton optEnglishToMetric;
        private System.Windows.Forms.RadioButton optMetricToEnglish;
        private System.Windows.Forms.Button btnConvert;
        private System.Windows.Forms.Button btnReset;
    }
}

