﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace English_To_MetricConverter
{
    class Metric_To_English
    {
        private double inches;
        private int miles;
        private int feet;
        private int yards;
        public Metric_To_English()
        {

        }

        public bool conversionForMetric(string userKilo, string userMeters, string userCentimeters)
        {
            try
            {
                Convert.ToInt16(userKilo);
                Convert.ToInt16(userMeters);
                Convert.ToInt16(userCentimeters);
            }
            catch
            {
                return false;
            }
            
            int meters = kilometerToMeters(int.Parse(userKilo)) + Convert.ToInt16(userMeters);
            int centimeters = metersToCentimeters(meters) + Convert.ToInt16(userCentimeters);
            inches = centimeterToInches(centimeters);

            feet = inchesToFeet(inches);
            yards = feetToYards(feet);
            miles = yardsToMiles(yards);

            return true;
        }

        public int kilometerToMeters(int a )
        {
            return a * 1000;
        }

        public int metersToCentimeters(int a)
        {
            return a * 100;
            
        }

        public double centimeterToInches(double a)
        {
            return a / 2.54;
        }

        public int inchesToFeet(double a)
        {
            return (int)a / 12;
           
        }

        public int feetToYards(int feet)
        {
            return feet / 3;
            
        }

        public int yardsToMiles(int yards)
        {

            return yards / 1760;
            
        }

        public string getInches()
        {
            return Convert.ToString(inches);
        }

        public string getFeet()
        {
            return Convert.ToString(feet);
        }

        public string getYards()
        {
            return Convert.ToString(yards);
        }

        public string getMiles()
        {
            return Convert.ToString(miles);
        }


    }
}