﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace English_To_MetricConverter
{
    public partial class frmEnglishToMetric : Form
    {
        English_To_Metric convertToMetric = new English_To_Metric();
        Metric_To_English convertToEnglish = new Metric_To_English();

        public frmEnglishToMetric()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
          
            if (optEnglishToMetric.Checked)
             {
                 convertToMetric.Conversion(txtMiles.Text, txtInches.Text, txtFeet.Text, txtYards.Text);

                 txtCenti.Text = convertToMetric.getCentimeters();
                 txtMeters.Text = convertToMetric.getMeter();
                 txtKilo.Text = convertToMetric.getKilometer();
             }

            if (optMetricToEnglish.Checked)
            {
                convertToEnglish.conversionForMetric(txtMetricKilo.Text, txtMetricMeter.Text, txtMetricCenti.Text);

                txtMetricInches.Text = convertToEnglish.getInches();
                txtMetricFeet.Text = convertToEnglish.getFeet();
                txtMetricYard.Text = convertToEnglish.getYards();
                txtMetricMiles.Text = convertToEnglish.getMiles();
            }
            
            
        }

        private void txtMiles_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMetricInches_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMetricKilo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMetricCenti_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtMeter_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmEnglishToMetric_Load(object sender, EventArgs e)
        {

        }

        private void optEnglishToMetric_CheckedChanged(object sender, EventArgs e)
        {
            grpEnglishToMetric.Enabled = true;
            grpMetricEnglishToMetric.Enabled = true;
            optMetricToEnglish.Enabled = false;
        }

        private void optMetricToEnglish_CheckedChanged(object sender, EventArgs e)
        {
            optEnglishToMetric.Enabled = false;
            grpMetricToEnglish.Enabled = true;
            grpEnglishMetricToEnglish.Enabled = true;
        }

        private void grpEnglishMetricToEnglish_Enter(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            if(optEnglishToMetric.Checked)
            {
                optEnglishToMetric.Checked = false;
                grpEnglishToMetric.Enabled = false;
                grpMetricEnglishToMetric.Enabled = false;

                optMetricToEnglish.Enabled = true;
            }

            if (optMetricToEnglish.Checked)
            {
                optMetricToEnglish.Checked = false;
                grpMetricToEnglish.Enabled = false;
                grpEnglishMetricToEnglish.Enabled = false;

                optEnglishToMetric.Enabled = true;
            }


        }

        private void btnEnglishToMetricClear_Click(object sender, EventArgs e)
        {
            txtMiles.Clear();
            txtYards.Clear();
            txtInches.Clear();
            txtFeet.Clear();
        }

        private void btnMetricEnglishToMetricClear_Click(object sender, EventArgs e)
        {
            txtKilo.Clear();
            txtMeters.Clear();
            txtCenti.Clear();
        }

        private void btnMetricToEnglishClear_Click(object sender, EventArgs e)
        {
            txtMetricKilo.Clear();
            txtMetricMeter.Clear();
            txtMetricCenti.Clear();
        }

        private void btnEnglishMetricToEnglishClear_Click(object sender, EventArgs e)
        {
            txtMetricMiles.Clear();
            txtMetricFeet.Clear();
            txtMetricInches.Clear();
            txtMetricYard.Clear();
        }
    }
}
