﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace English_To_MetricConverter
{
     class English_To_Metric
    {
        private double _centimeters;
        private int _meters;
        private int _kilometers;

        public English_To_Metric()
        {
          
        }

        public bool Conversion(string userMiles, string userYards, string userFeet, string userInches)
        {
           try
            {
                Convert.ToInt16(userMiles);
                Convert.ToInt16(userYards);
                Convert.ToInt16(userFeet);
                Convert.ToInt16(userInches);

            }
            catch
            {
                return false;
            }
            

            int totalYards = milesToYards(int.Parse(userMiles)) + Convert.ToInt32(userYards);
            int totalFeet = yardsToFeet(totalYards) + Convert.ToInt32(userFeet);
            double totalInches = feetToInches(totalFeet) + Convert.ToInt32(userInches);

            _centimeters = inchesToCenti(totalInches);
            _meters = centiToMeter(_centimeters);
            _kilometers = metersToKilometers(_meters);




            return true;
        }
        public int milesToYards(int a)
        {
            return a * 1760;
        }

        public int yardsToFeet(int a)
        {
            return  a * 3;
        }

        public double feetToInches(int a)
        {
             return a * 12;
        }

        public double inchesToCenti(double a)
        {
             return a * 2.54;
        }

        public int centiToMeter(double a)
        {
             return (int)a / 100;
        }

        public int metersToKilometers(double a)
        {
             return (int)a / 1000;
        }
        public string getCentimeters()
        {
            return Convert.ToString(_centimeters);
        }
        public string getMeter()
        {
            return Convert.ToString(_meters);
        }
        public string getKilometer()
        {
            return Convert.ToString(_kilometers);
        }

    }
}